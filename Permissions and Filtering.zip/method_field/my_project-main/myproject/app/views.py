from django.shortcuts import redirect, render
from app.models import registration_form
from django.core.mail import send_mail
from django.conf import settings
from app.serializers import TestFormSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.views import APIView
from app.models import employeeDetails
from app.serializers import employee
from app.models import companyDetails
from app.serializers import companySerializer
from rest_framework import mixins
from rest_framework import generics, filters
from rest_framework.permissions import IsAdminUser
from app.permissions import AdminOrReadOnly
# from rest_framework.filters import OrderingFilter


# Create your views here.


@api_view(['GET', 'POST'])
def getdata(request):
    if request.method == "GET":
        gett = registration_form.objects.all()
        serializer = TestFormSerializer(gett, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    if request.method == "POST":
        serializer = TestFormSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


@api_view(['GET', 'PUT', 'DELETE'])
def getdataupdate(request, pk):
    if request.method == 'PUT':
        get1 = registration_form.objects.get(pk=pk)
        serializer = TestFormSerializer(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    if request.method == 'DELETE':
        get2 = registration_form.objects.get(pk=pk)
        get2.delete()
    return Response("data deleted successfully")


# CRUD Operations in Class Based View
class crudOperations(APIView):

    def get(self, request):
        gett = registration_form.objects.all()
        serializer = TestFormSerializer(gett, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def post(self, request):
        serializer = TestFormSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_201_CREATED)


class crud_update_delete(APIView):

    def get(self, request, pk):
        gett = registration_form.objects.get(pk=pk)
        serializer = TestFormSerializer(gett)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def put(self, request, pk):
        get1 = registration_form.objects.get(pk=pk)
        serializer = TestFormSerializer(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def delete(self, request, pk):
        get2 = registration_form.objects.get(pk=pk)
        get2.delete()
        return Response("data deleted successfully")

# using mixin


class mixin_get  (mixins.ListModelMixin,
                  mixins.CreateModelMixin,
                  generics.GenericAPIView):
    queryset = employeeDetails.objects.all()
    serializer_class = employee

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class mixin_update (mixins.RetrieveModelMixin,
                    mixins.UpdateModelMixin,
                    mixins.DestroyModelMixin,
                    generics.GenericAPIView):
    queryset = employeeDetails.objects.all()
    serializer_class = employee

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

# using geniric class based views data


class generic_data(generics.ListCreateAPIView):
    queryset = employeeDetails.objects.all()
    serializer_class = employee
    filter_backends = [filters.SearchFilter]
    search_fields = ['emp_name', 'emp_surname', 'emp_address', 'emloyee_email']
    # filter_backends = [OrderingFilter]
    permission_classes = [IsAdminUser]
    permission_classes = [AdminOrReadOnly]


class generic_update(generics.RetrieveUpdateDestroyAPIView):
    queryset = employeeDetails.objects.all()
    serializer_class = employee

# CRUD operations for employeeDetail Model


class employee_details(APIView):

    def get(self, request):
        gett = employeeDetails.objects.all()
        serializer = employee(gett, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def post(self, request):
        serializer = employee(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_201_CREATED)


class employee_update(APIView):

    def get(self, request, pk):
        gett = employeeDetails.objects.get(pk=pk)
        serializer = employee(gett)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def put(self, request, pk):
        get1 = employeeDetails.objects.get(pk=pk)
        serializer = employee(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def delete(self, request, pk):
        get2 = employeeDetails.objects.get(pk=pk)
        get2.delete()
        return Response("data deleted successfully")


# company details
class company_details(APIView):

    def get(self, request):
        gett = companyDetails.objects.all()
        serializer = companySerializer(gett, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def post(self, request):
        serializer = companySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_201_CREATED)


class company_update(APIView):

    def get(self, request, pk):
        gett = companyDetails.objects.get(pk=pk)
        serializer = companySerializer(gett)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def put(self, request, pk):
        get1 = companyDetails.objects.get(pk=pk)
        serializer = companySerializer(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def delete(self, request, pk):
        get2 = companyDetails.objects.get(pk=pk)
        get2.delete()
        return Response("data deleted successfully")


def home(request):
    return render(request, 'home.html')


def registration_form_fun(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')

        obj = registration_form.objects.create(fname=fname, lname=lname, email=email, phone=phone)
        obj.save()

    # Mail Sending
        send_mail(
           "thanks for contacting",
           f"Mr/Mrs {fname} thanks for contacting us",
           settings.EMAIL_HOST_USER,
           [email],
           fail_silently=False
        )

        return redirect("get_registration_form_fun")

    return render(request, "registration_form.html")

# CRUD Operations in Function Basaed View


def get_registration_form_fun(request):
    users = registration_form.objects.all()
    obj = {"user_obj": users}
    return render(request, "registration_form_get_data.html", obj)


def update_registration_form_fun(request, id):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')

        users = registration_form.objects.get(id=id)
        users.fname = fname
        users.lname = lname
        users.email = email
        users.phone = phone
        users.save()
        return redirect('get_registration_form_fun')
    users = registration_form.objects.get(id=id)
    obj = {"user_obj": users}
    users.save()
    return render(request, 'update.html', obj)


def delete_registration_form_fun(request, id):
    users = registration_form.objects.get(id=id)
    users.delete()
    return redirect("get_registration_form_fun")
