from rest_framework.throttling import UserRateThrottle


class generic_data_throtting(UserRateThrottle):
    scope = 'generic-list'
