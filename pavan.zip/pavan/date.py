import datetime as dt
current_datetime=dt.datetime.now()
print(current_datetime)
string_date=current_datetime.strftime("%b %d, %I %p")
print(string_date) 