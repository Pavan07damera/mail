# lamda function
str1='pavankalyan'
result=lambda x:x.upper()[::-1]
print(result(str1))