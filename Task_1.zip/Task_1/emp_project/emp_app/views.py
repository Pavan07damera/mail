from django.shortcuts import render
from emp_app.models import emp_table
from emp_app.serializer import emp_Serializer
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core.mail import send_mail
from django.conf import Settings
from rest_framework import filters


"""storing data"""
def test(request):
    if request.method == "POST":
        emp_name = request.POST.get("emp_name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        department = request.POST.get("department")
        salary = request.POST.get("salary")
        task = request.POST.get("task")
        work_progress = request.POST.get("work_progress")
        manager_name = request.POST.get("manager_name")
        file = request.POST.get("file")
        obj = emp_table.objects.create(
            employee_name=emp_name,
            email=email,
            phone=phone,
            department=department,
            salary=salary,
            task=task,
            work_progress=work_progress,
            manager_name=manager_name,
            file=file,
        )
        obj.save()
        """sending mail"""
        send_mail(
            'Application status ', #subject
            f'Hello Mr.{emp_name} \n We are currently reviewing your application once it done. we will communicate through the email.',     # email body
            # settings.EMAIL_HOST_USER, #sender
            # [email], #receiver
            fail_silently=False,
        )
    return render(request, "register.html")


"""class based API view"""
class get_data(APIView):
    def get(self, request):
        get1 = emp_table.objects.all()
        serializer = emp_Serializer(get1, many=True)
        return Response(serializer.data)
    filter_backends = [filters.SearchFilter]   # SearchFilter
    search_fields = ['email', 'phone', 'department', 'manager_name']
    
    def post(self, request):
        serializer = emp_Serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


class update_data(APIView):
    def get(self, request, pk):
        get1 = emp_table.objects.all()    
        serializer = emp_Serializer(get1, many=True)
        return Response(serializer.data)
    
    def put(self, request, pk):
        get2 = emp_table.objects.get(pk=pk)
        serializer = emp_Serializer(get2, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    
    def delete(self, request, pk):
        get3 = emp_table.objects.get(pk=pk)
        get3.delete()
        return Response({"status : deleted sucessfully"})


