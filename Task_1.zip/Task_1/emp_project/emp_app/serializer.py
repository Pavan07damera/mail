from rest_framework import serializers
from emp_app.models import emp_table


class emp_Serializer(serializers.ModelSerializer):

    class Meta:
        model = emp_table
        fields = "__all__"

    """object level validation"""
    def validate(self, data):
        if len(data['employee_name']) >= 5:
            raise serializers.ValidationError("You dont have to take more than 5 characters")
        elif emp_table.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError("email alredy existed")
        #elif data['email'] == nullcontext:
            raise serializers.ValidationError("dont leave the email field empty")
        #elif data['address'] != Number:
            raise serializers.ValidationError("you may not give int value")
        else:
            return data