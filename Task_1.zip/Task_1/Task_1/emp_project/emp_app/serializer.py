from rest_framework import serializers
from emp_app.models import emp_table


class emp_Serializer(serializers.ModelSerializer):

    class Meta:
        model = emp_table
        fields = "__all__"

    """object level validation"""
    def validate(self, data):
        if len(data['emp_name']) <= 4:
            raise serializers.ValidationError("You dont have to take more than 4 characters")
        elif emp_table.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError("email alredy existed")
        return data
