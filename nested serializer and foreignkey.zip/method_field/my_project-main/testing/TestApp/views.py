from django.shortcuts import render, redirect
from TestApp.models import TestForm
from django.core.mail import send_mail
from TestApp.serializers import TestFormSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
# Create your views here.

@api_view(['GET', 'POST'])
def getdata(request, pk):
    if request.method == "GET":
        gett = TestForm.objects.all()
        serializer = TestFormSerializer(gett, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    if request.method == "POST":
        serializer = TestFormSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    
@api_view(['GET','PUT', 'DELETE'])
def getdataupdate(request, pk):
    if request.method == 'PUT':
        get1 = TestForm.objects.get(pk=pk)
        serializer = TestFormSerializer(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
    if request.method == 'DELETE':
        get2 = TestForm.objects.get(pk=pk)
        get2.delete()
        return Response("data deleted successfully")







def test(request):
    if request.method == "POST":
        name = request.POST.get('name')
        description = request.POST.get('description')
        email = request.POST.get('email')
        obj = TestForm.objects.create(name = name, description = description, email = email)
        obj.save()
        # send_mail(
        #     'Subject here',
        #     'Here is the message.',
        #     'from@example.com',
        #     ['to@example.com'],
        #     fail_silently=False,
        # )
        return redirect('userdata')

    return render(request, 'index.html')



def userdata(request):
    users = TestForm.objects.all()
    obj = {"user_obj": users}
    return render(request, 'userdata.html', obj)


def updatedata(request, id):
    if request.method == "POST":
        name = request.POST.get('name')
        description = request.POST.get('description')
        email = request.POST.get('email')
        users = TestForm.objects.get(id=id)
        users.name = name
        users.description = description
        users.email = email
        users.save()
        return redirect('userdata')
    users = TestForm.objects.get(id=id)
    obj = {"user_obj": users}
    return render(request, 'update.html', obj)



def deletedata(request, id):
    users = TestForm.objects.get(id=id)
    users.delete()
    return redirect('userdata')