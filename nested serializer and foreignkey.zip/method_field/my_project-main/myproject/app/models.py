from django.db import models

# Create your models here.
class registration_form(models.Model):
    fname = models.CharField(max_length=20)
    lname = models.CharField(max_length=20)
    email = models.EmailField(null = True)
    phone = models.IntegerField(null=True)
   
    
    def __str__(self):
        return f"{self.fname} {self.lname}"
    

# company details
class companyDetails(models.Model):
    company_name = models.CharField(max_length=100, null=True)
    company_address = models.CharField(max_length=100, null=True)
    company_type = models.CharField(max_length=100, null=True)
    company_num = models.IntegerField(null=True)

    def __str__(self) -> str:
        return f"{self.company_name}"

#Employee Model
class employeeDetails(models.Model):
    company_name=models.ForeignKey(companyDetails, on_delete=models.CASCADE, related_name="employeee")
    emp_name = models.CharField(max_length=100, null=True)
    emp_surname = models.CharField(max_length=100, null=True)
    emp_address = models.CharField(max_length=100, null=True)
    emloyee_email =models.EmailField(null=True)
    active = models.BooleanField(default=True, null=True)
    created_at = models.DateTimeField(null=True)
    update_at = models.DateTimeField(null=True)
    
    
    def __str__(self) -> str:
        return f"{self.emp_name}"