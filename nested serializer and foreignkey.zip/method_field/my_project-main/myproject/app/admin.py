from django.contrib import admin
from.models import registration_form, employeeDetails,companyDetails

# Register your models here.
admin.site.register(registration_form)
admin.site.register(employeeDetails)
admin.site.register(companyDetails)