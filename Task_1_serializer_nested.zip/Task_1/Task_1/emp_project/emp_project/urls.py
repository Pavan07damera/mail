"""
URL configuration for emp_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from emp_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('register', views.test, name='test'),
    path('department_data', views.Department_data.as_view(), name='department_data'),
    path('department_update/<int:pk>/', views.Department_update.as_view(), name='department_update'),
    path('get_data', views.get_data.as_view()),
    path('update_data/<int:pk>/', views.update_data.as_view()),
    path('generic_data', views.generic_data.as_view(), name='generic_data'),
    path('generic_update/<int:pk>/', views.generic_update.as_view(), name='generic_update'),
    path('emp_data', views.Emp_data.as_view(), name='emp_data'),
    path('emp_update/<int:pk>/', views.Emp_update.as_view(), name='emp_update'),

    
]
