from django.db import models

# Create your models here.

"""Model for Generic data"""


class emp_table(models.Model):
    emp_name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.IntegerField(null=True)
    salary = models.IntegerField(null=True)
    task = models.CharField(max_length=20)
    work_progress = models.CharField(max_length=100)
    manager_name = models.CharField(max_length=100)
    file = models.FileField(upload_to="uploads/", max_length=100, null=True, default=None)

    def __str__(self) -> str:
        return f"{self.emp_name}"


"""Model For Dpartment data"""


class Department_details(models.Model):
    department = models.CharField(max_length=100)
    salary = models.IntegerField(null=True)

    def __str__(self) -> str:
        return f"{self.department}"


"""Model For Manager Data"""


class Emp_details(models.Model):
    department = models.ForeignKey(Department_details, on_delete=models.CASCADE, related_name="department_data", null=True)
    manager_name = models.ForeignKey(emp_table, on_delete=models.CASCADE, related_name="generic_data", null=True)
    emp_name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.IntegerField(null=True)
    address = models.CharField(max_length=100, default=None)
    file = models.FileField(upload_to="uploads/", max_length=100, null=True, default=None)

    def __str__(self) -> str:
        return f"{self.emp_name}"
