from django.contrib import admin
from emp_app.models import emp_table, Emp_details, Department_details

# Register your models here.
admin.site.register(emp_table)
admin.site.register(Emp_details)
admin.site.register(Department_details)



