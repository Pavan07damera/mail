from rest_framework import serializers
from emp_app.models import emp_table, Emp_details, Department_details

"""manager SErializer"""


class Employee_Serializer(serializers.ModelSerializer):

    class Meta:
        model = Emp_details
        fields = "__all__"


"""Department Serializer"""


class Department_Serializer(serializers.ModelSerializer):
    department_data = Employee_Serializer(many=True, read_only=True)

    class Meta:
        model = Department_details
        fields = "__all__"


"""Employee Serializer"""


class emp_Serializer(serializers.ModelSerializer):
    generic_data = Department_Serializer(many=True, read_only=True)
    upper = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = emp_table
        fields = "__all__"
    '''method field'''
    def get_upper(self, obj):
        upper = (obj.emp_name).upper()
        return upper
    """object level validation"""
    def validate(self, data):
        if len(data['emp_name']) <= 4:
            raise serializers.ValidationError("You dont have to take more than 4 characters")
        elif emp_table.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError("email alredy existed")
        elif (data['salary']) < 10000 or (data['salary']) > 50000:
            raise serializers.ValidationError("salary between 10000 and 50000")
        return data
