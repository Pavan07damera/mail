from django.contrib import admin
from emp_app.models import emp_table, manager_detail, department_details

# Register your models here.
admin.site.register(emp_table)
admin.site.register(manager_detail)
admin.site.register(department_details)
