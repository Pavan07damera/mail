from django.db import models

# Create your models here.
class registration_form(models.Model):
    fname = models.CharField(max_length=20)
    lname = models.CharField(max_length=20)
    email = models.EmailField(null = True)
    phone = models.IntegerField(null=True)
   
    
    def __str__(self):
        return f"{self.fname} {self.lname}"
    
#Employee Model
class employeeDetails(models.Model):
    emp_name = models.CharField(max_length=100)
    emp_surname = models.CharField(max_length=100)
    emp_address = models.CharField(max_length=100)
    emloyee_email =models.EmailField(null=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)
    
    
    def __str__(self) -> str:
        return f"{self.emp_name}"