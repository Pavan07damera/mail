from django.contrib import admin
from django.urls import path
from app import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name="home"),
    path('registration_form', views.registration_form_fun, name="registration_form_fun"),
    path('get_registration_form_fun', views.get_registration_form_fun, name="get_registration_form_fun"),
    path('update_registration_form_fun/<id>', views.update_registration_form_fun, name='update_registration_form_fun'),
    path('delete_registration_form_fun/<id>', views.delete_registration_form_fun, name='delete_registration_form_fun'),
    path('getdata/', views.getdata, name='getdata'),
    path('getdata/<int:pk>/', views.getdataupdate, name='getdataupdate'),
    path('crud_get', views.crudOperations.as_view()),
    path('crud_update/<int:pk>/', views.crud_update_delete.as_view()),
    path('emp_details', views.employee_details.as_view()),
    path('emp_update/<int:pk>/', views.employee_update.as_view()),
    path('company_details', views.company_details.as_view()),
    path('company_update/<int:pk>/', views.company_update.as_view()),
    path('mixin_data', views.mixin_get.as_view()),
    path('mixin_update/<int:pk>/', views.mixin_update.as_view()),
    path('generic_data', views.generic_data.as_view()),
    path('generic_update/<int:pk>/', views.generic_update.as_view()),

]
