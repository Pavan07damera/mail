from rest_framework import serializers
from TestApp.models import TestForm


class TestFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = TestForm
        fields = "__all__"