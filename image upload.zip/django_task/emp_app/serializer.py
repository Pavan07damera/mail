from rest_framework import serializers
from emp_app.models import emp_table, manager_detail, department_details

"""Employee SErializer"""


class emp_Serializer(serializers.ModelSerializer):
    upper = serializers.SerializerMethodField(read_only=True)  # method field

    class Meta:
        model = emp_table
        fields = "__all__"
    '''method field'''
    def get_upper(self, obj):
        upper = (obj.emp_name).upper()
        return upper

    """object level validation"""

    def validate(self, data):
        if len(data['emp_name']) <= 4:
            raise serializers.ValidationError("You dont have to take more than 4 characters")
        elif emp_table.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError("email alredy existed")

        return data


"""Department Serializer"""


class department_Serializer(serializers.ModelSerializer):
    department_data = emp_Serializer(many=True, read_only=True)

    class Meta:
        model = department_details
        fields = "__all__"

    def validate(self, data):

        if (data['salary']) < 10000 or (data['salary']) > 50000:
            raise serializers.ValidationError("salary between 10000 and 50000")

        return data


"""Manager Serializer"""


class manager_Serializer(serializers.ModelSerializer):
    manager_data = department_Serializer(many=True, read_only=True)

    class Meta:
        model = manager_detail
        fields = "__all__"
