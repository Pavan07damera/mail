from rest_framework import serializers
from app.models import registration_form


class TestFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = registration_form
        fields = "__all__"

    def validate(self,attrs):
        num=attrs.get('phone')
        n=str(num)
        if (attrs['fname'] == attrs['lname']):
            raise serializers.ValidationError("fname and lname shold be different")
        
        elif registration_form.objects.filter(email=attrs['email']).exists():
            raise serializers.ValidationError("Email already exists")
        
        elif len(attrs['fname'])<3:
              raise serializers.ValidationError("fname len should be greater than 3")
        
        elif len(n) !=10:
            raise serializers.ValidationError("len of the phone should be equal to 10")
        else:
            return attrs

    def validate_lname(self,data):
        if len(data)<3:
            raise serializers.ValidationError("len of the lname should be greaterthan 3")
        return data
    


