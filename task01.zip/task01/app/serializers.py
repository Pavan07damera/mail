from contextlib import nullcontext
from numbers import Number
from rest_framework import serializers
from app.models import Employee_db


class EmpSerializer(serializers.ModelSerializer):

    class Meta:
        model = Employee_db
        fields = "__all__"

    """object level validation"""
    def validate(self, data):
        if len(data['employee_name']) >= 5:
            raise serializers.ValidationError("You dont have to take more than 5 characters")
        elif Employee_db.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError("email alredy existed")
        elif data['email'] == nullcontext:
            raise serializers.ValidationError("dont leave the email field empty")
        elif data['address'] != Number:
            raise serializers.ValidationError("you may not give int value")
        else:
            return data