from django.contrib import admin
from app.models import Employee_db

# Register your models here.
admin.site.register(Employee_db)
