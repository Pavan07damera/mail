from django.shortcuts import render
from app.models import Employee_db
from app.serializers import EmpSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core.mail import send_mail
from django.conf import Settings
from rest_framework import filters


"""storing data"""
def test(request):
    if request.method == "POST":
        employee_name = request.POST.get("employee_name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        department = request.POST.get("department")
        salary = request.POST.get("salary")
        task = request.POST.get("task")
        work_progress = request.POST.get("work_progress")
        manager_name = request.POST.get("manager_name")
        file = request.POST.get("file")
        obj = Employee_db.objects.create(
            employee_name=employee_name,
            email=email,
            phone=phone,
            department=department,
            salary=salary,
            task=task,
            work_progress=work_progress,
            manager_name=manager_name,
            file=file,
        )
        obj.save()
        """sending mail"""
        send_mail(
            'Application status ', #subject
            f'Hello Mr.{employee_name} \n We are currently reviewing your application once it done. we will communicate through the email.',     # email body
            settings.EMAIL_HOST_USER, #sender
            [email], #receiver
            fail_silently=False,
        )
    return render(request, "register.html")


"""class based API view"""
class get_data(APIView):
    def get(self, request):
        get1 = Employee_db.objects.all()
        serializer = EmpSerializer(get1, many=True)
        return Response(serializer.data)
    filter_backends = [filters.SearchFilter]   # SearchFilter
    search_fields = ['email', 'phone', 'department', 'manager_name']
    
    def post(self, request):
        serializer = EmpSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


class update_data(APIView):
    def get(self, request, pk):
        get1 = Employee_db.objects.all()    
        serializer = EmpSerializer(get1, many=True)
        return Response(serializer.data)
    
    def put(self, request, pk):
        get2 = Employee_db.objects.get(pk=pk)
        serializer = EmpSerializer(get2, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    
    def delete(self, request, pk):
        get3 = Employee_db.objects.get(pk=pk)
        get3.delete()
        return Response({"status : deleted sucessfully"})

