from django.db import models

# Create your models here.

class TestForm(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=50)
    email = models.EmailField()


    def __str__(self) -> str:
        return f"{self.name}"