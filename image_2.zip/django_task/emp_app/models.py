from django.db import models

# Create your models here.

DEPARTMENT_CHOICES = (
    ("Machine Learning", "Machine Learning"),
    ("Python Development", "Python Development"),
    ("PHP Development", "PHP Development"),
    ("UI/UX Design", "UI/UX Design"),
    ("React JS", "React JS"),
    ("Digital Marketing", "Digital Marketing"),
)

TASK_CHOICE = (
    ('Complete', 'Complete'),
    ('incomplete', 'Incomplete')
)


"""Department_Details"""


class department_details(models.Model):
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES, default='1', null=True)
    salary = models.IntegerField(null=True)
    tasks = models.CharField(max_length=20, choices=TASK_CHOICE, default='1', null=True)
    work_progress = models.TextField(null=True)

    def __str__(self):
        return f"{self.department}"


"""Manager Details"""


class manager_detail(models.Model):
    manager = models.CharField(max_length=50, unique=True)

    def __str__(self) -> str:
        return f"{self.manager}"


"""Employee Details"""


class emp_table(models.Model):
    department = models.ForeignKey(department_details, on_delete=models.CASCADE, related_name="department_data", null=True)
    manager = models.ForeignKey(manager_detail, on_delete=models.CASCADE, related_name = "manager_data", null=True)
    emp_name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.IntegerField(null=True)
    address = models.CharField(max_length=100, null=True)
    marital_status = models.CharField(max_length=50, null=True)
    file = models.FileField(upload_to="media/", max_length=100, null=True, default=None)

    def __str__(self) -> str:
        return f"{self.emp_name}"
