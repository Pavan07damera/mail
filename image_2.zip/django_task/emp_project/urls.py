"""
URL configuration for emp_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from emp_app import views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('register', views.test, name='test'),
    path('department_data', views.department_data.as_view(), name='department_data'),
    path('department_update/<int:pk>/', views.department_update.as_view(), name='department_update'),
    path('get_data', views.get_data.as_view()),
    path('get_update/<int:pk>/', views.update_data.as_view()),
    path('emp_data', views.emp_data.as_view(), name='emp_data'),
    path('emp_update/<int:pk>/', views.emp_update.as_view(), name='emp_update'),
    path('manager_data', views.manager_data.as_view(), name='manager_data'),
    path('manager_update/<int:pk>/', views.manager_update.as_view(), name='manager_update'),


]

"""for file upload"""
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
