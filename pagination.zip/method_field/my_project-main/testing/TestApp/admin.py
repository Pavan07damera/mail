from django.contrib import admin
from TestApp.models import TestForm
# Register your models here.

admin.site.register(TestForm)
