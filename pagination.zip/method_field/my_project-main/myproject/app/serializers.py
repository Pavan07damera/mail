from rest_framework import serializers
from app.models import registration_form
from app.models import employeeDetails
from app.models import companyDetails


class TestFormSerializer(serializers.ModelSerializer):
    len_name = serializers.SerializerMethodField(read_only=True)
    upper = serializers.SerializerMethodField(read_only=True)
    len_phone = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = registration_form
        fields = "__all__"

    # Method Field
    def get_len_name(self, obj):
        lenghth = len(obj.fname)
        return lenghth

    def get_upper(self, obj):
        upper = (obj.lname).upper()
        return upper

    def get_len_phone(self, obj):
        get_phone_len = len(str(obj.phone))
        return get_phone_len

    # Validations
    def validate(self, attrs):
        num = attrs.get('phone')
        n = str(num)
        if (attrs['fname'] == attrs['lname']):
            raise serializers.ValidationError("fname and lname shold be diff")

        elif registration_form.objects.filter(email=attrs['email']).exists():
            raise serializers.ValidationError("Email already exists")

        elif len(attrs['fname']) < 3:
            raise serializers.ValidationError("len should be greater than 3")

        elif len(n) != 10:
            raise serializers.ValidationError("phone should be equal to 10")
        else:
            return attrs

    # Validation in Fieldtype
    def validate_lname(self, data):
        if len(data) < 3:
            raise serializers.ValidationError("len should greater 3")
        return data

# serializer for emp_details'''


class employee(serializers.ModelSerializer):
    emp_user = serializers.StringRelatedField(read_only=True)
    # company_name = serializers.SerializerMethodField(source='get_company_name') # for display company_name

    class Meta:

        model = employeeDetails
        fields = "__all__"

    # def get_company_name(self, obj): # display company_name
    #      display = str(obj.company_name)
    #      return display
# Serializer for company_details


class companySerializer(serializers.ModelSerializer):
    employeee = employee(many=True, read_only=True)  # nested serializer
    # employeee = serializers.SlugRelatedField(
    #     many=True,
    #     read_only=True,
    #     slug_field='emp_surname'
    #  )
    # employeee = serializers.PrimaryKeyRelatedField(many=True, read_only=True)
    # employeee = serializers.StringRelatedField(many=True)
    # employeee = serializers.HyperlinkedRelatedField(
    #     many=True,
    #     read_only=True,
    #     view_name='generic_update'
    # )

    class Meta:
        model = companyDetails
        fields = "__all__"
