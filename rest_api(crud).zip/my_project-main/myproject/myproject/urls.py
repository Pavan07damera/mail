from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name="home"),
    path('registration_form',views.registration_form_fun,name="registration_form_fun"),
    path('get_registration_form_fun',views.get_registration_form_fun,name="get_registration_form_fun"),
    path('update_registration_form_fun/<id>',views.update_registration_form_fun,name = 'update_registration_form_fun'),
    path('delete_registration_form_fun/<id>',views.delete_registration_form_fun,name = 'delete_registration_form_fun'),
    path('getdata/', views.getdata, name='getdata'),
    path('getdata/<int:pk>/', views.getdataupdate, name='getdataupdate'),
]

