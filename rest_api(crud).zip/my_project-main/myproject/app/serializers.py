from rest_framework import serializers
from app.models import registration_form


class TestFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = registration_form
        fields = "__all__"