from django.shortcuts import redirect, render,HttpResponse
from app.models import registration_form
from django.core.mail import send_mail
from django.conf import settings
from app.serializers import TestFormSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
# Create your views here.
@api_view(['GET', 'POST'])
def getdata(request):
    if request.method == "GET":
        gett = registration_form.objects.all()
        serializer = TestFormSerializer(gett, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    if request.method == "POST":
        serializer = TestFormSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    
@api_view(['GET','PUT', 'DELETE'])
def getdataupdate(request, pk):
    if request.method == 'PUT':
        get1 = registration_form.objects.get(pk=pk)
        serializer = TestFormSerializer(get1, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    if request.method == 'DELETE':
        get2 = registration_form.objects.get(pk=pk)
        get2.delete()
    return Response("data deleted successfully")


def home(request):
    return render(request,'home.html')



def registration_form_fun(request):
    if request.method=='POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        
        obj = registration_form.objects.create(fname = fname,lname = lname,email = email,phone = phone)
        obj.save()
        send_mail(
           "thanks for contacting",
            f"Mr/Mrs {fname} thanks for contacting us",
            settings.EMAIL_HOST_USER,
            [email],
            fail_silently=False
        )

        
        return redirect("get_registration_form_fun")
        
    return render(request,"registration_form.html")


def get_registration_form_fun(request):
    users = registration_form.objects.all()
    obj ={"user_obj":users}
    return render(request,"registration_form_get_data.html",obj)


def update_registration_form_fun(request, id):
    if request.method=='POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        
        users = registration_form.objects.get(id=id)
        users.fname = fname
        users.lname = lname
        users.email = email
        users.phone = phone
        users.save()
        return redirect('get_registration_form_fun')
    users = registration_form.objects.get(id=id)
    obj = {"user_obj":users}
    users.save()
    return render(request,'update.html',obj)

def delete_registration_form_fun(request,id):
    users = registration_form.objects.get(id=id )
    users.delete()
    return redirect("get_registration_form_fun")

   

