from django.contrib import admin
from .models import registration_form

# Register your models here.
admin.site.register(registration_form)