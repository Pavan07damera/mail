from django.contrib import admin
from django.urls import path, include
from app import views
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from rest_framework_simplejwt.views import TokenBlacklistView

urlpatterns = [
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/token/blacklist/', TokenBlacklistView.as_view(), name='token_blacklist'),
    path('admin/', admin.site.urls),
    path('user_auth', include('rest_framework.urls')),
    path('', views.home, name="home"),
    path('registration_form', views.registration_form_fun, name="registration_form_fun"),
    path('get_registration_form_fun', views.get_registration_form_fun, name="get_registration_form_fun"),
    path('update_registration_form_fun/<id>', views.update_registration_form_fun, name='update_registration_form_fun'),
    path('delete_registration_form_fun/<id>', views.delete_registration_form_fun, name='delete_registration_form_fun'),
    path('getdata/', views.getdata, name='getdata'),
    path('getdata/<int:pk>/', views.getdataupdate, name='getdataupdate'),
    path('crud_get', views.crudOperations.as_view()),
    path('crud_update/<int:pk>/', views.crud_update_delete.as_view()),
    path('emp_details', views.employee_details.as_view(), name='emp_details'),
    path('emp_update/<int:pk>/', views.employee_update.as_view(), name='emp_update'),
    path('company_details', views.company_details.as_view(), name='company_details'),
    path('company_update/<int:pk>/', views.company_update.as_view(), name='company_update'),
    path('mixin_data', views.mixin_get.as_view()),
    path('mixin_update/<int:pk>/', views.mixin_update.as_view()),
    path('generic_data', views.generic_data.as_view(), name='generic_data'),
    path('generic_update/<int:pk>/', views.generic_update.as_view(), name='generic_update'),

]
